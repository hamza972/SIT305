package com.example.myapplication;

import android.content.SharedPreferences;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Chronometer chronometer;
    boolean IsRunning;
    long PausedTime;

    TextView WorkoutSum;
    EditText WorkoutType;
    SharedPreferences sharedPref;

    String Pre_Summary = "Previous_Summary";
    String Summary = "Summary";
    String Pause = "Pause";
    String Base = "Base";
    String Timer_Running = "Timmer_Running";

    public void onClick(View view)
    {
        switch (view.getId()){
            case R.id.play:
                if (!IsRunning){
                    chronometer.setBase(SystemClock.elapsedRealtime() - PausedTime);
                    chronometer.start();
                    IsRunning = true;
                }
                break;
            case R.id.pause:
                if(IsRunning){
                    chronometer.stop();
                    PausedTime = SystemClock.elapsedRealtime() - chronometer.getBase();
                    IsRunning = false;
                }
                break;
            case R.id.stop:
                CharSequence Time = chronometer.getText();
                if(WorkoutType.getText().toString().equals(""))
                {
                    WorkoutSum.setText("You have Spend " + Time.toString() + " on your previous workout time");

                }
                else
                {
                    WorkoutSum.setText("You have spend " + Time.toString() + " on " + WorkoutType.getText().toString() + " previous time");
                }
                chronometer.stop();
                chronometer.setBase(SystemClock.elapsedRealtime());
                PausedTime = 0;
                IsRunning = false;


                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString(Pre_Summary,WorkoutSum.getText().toString());
                editor.apply();
                break;



        }

    }

    private void loadSharedPrefrences()
    {
        String Text = sharedPref.getString(Pre_Summary,"Prev_Summary");
        WorkoutSum.setText(Text);
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chronometer = findViewById(R.id.timmer);
        WorkoutSum = findViewById(R.id.description);
        WorkoutType = findViewById(R.id.myWorkout);
        PausedTime  = SystemClock.elapsedRealtime() - chronometer.getBase();

        sharedPref = getSharedPreferences("com.example.WorkOutTimer",MODE_PRIVATE);
        loadSharedPrefrences();

        if (savedInstanceState !=null)
        {
            WorkoutSum.setText(savedInstanceState.getString(Summary));
            PausedTime = savedInstanceState.getLong(Pause);
            chronometer.setBase(SystemClock.elapsedRealtime() + savedInstanceState.getLong(Base));
            if (savedInstanceState.getBoolean(Timer_Running))
            {
                chronometer.start();
                IsRunning = true;
            }
            else {
                chronometer.setBase(SystemClock.elapsedRealtime() - PausedTime);
            }
        }
        else
        {
            IsRunning = false;
        }
    }
    protected void OnSavedInstanceState(Bundle OutState)
    {
        super.onSaveInstanceState(OutState);
        OutState.putString(Summary, WorkoutSum.getText().toString());
        OutState.putLong(Base,chronometer.getBase()-SystemClock.elapsedRealtime());
        OutState.putBoolean(Timer_Running,IsRunning);
        OutState.putLong(Pause,PausedTime);
    }
}